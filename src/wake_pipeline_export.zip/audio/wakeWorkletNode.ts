/**
 * AudioWorklet Node Wrapper for Wake Word Detection
 * 
 * Simplifies using the wake worklet processor
 * Handles initialization, message passing, and cleanup
 */

export class WakeWorkletNode {
  private audioContext: AudioContext;
  private workletNode: AudioWorkletNode | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private onFrameCallback: ((frame: Float32Array, sampleRate: number) => void) | null = null;
  private isInitialized = false;
  private resumeInterval: number | null = null;
  private resumeHandlers: Array<{ event: string; handler: () => void }> = [];

  constructor(audioContext: AudioContext) {
    this.audioContext = audioContext;
    this.setupIOSResumeHandlers();
    this.setupPeriodicResume();
  }

  /**
   * Initialize the AudioWorklet
   * Must be called after user gesture (iOS requirement)
   */
  async initialize(stream: MediaStream): Promise<void> {
    if (this.isInitialized) {
      console.warn('[WakeWorkletNode] Already initialized');
      return;
    }

    try {
      // Load the worklet processor - use the existing one in wakeword folder
      await this.audioContext.audioWorklet.addModule(
        new URL('../wakeword/WakeWordProcessor.worklet.js', import.meta.url)
      );

      // Create worklet node - name must match registerProcessor name
      this.workletNode = new AudioWorkletNode(
        this.audioContext,
        'wake-word-processor', // Must match registerProcessor name
        {
          numberOfInputs: 1,
          numberOfOutputs: 0, // We don't need output, just processing
          processorOptions: {},
        }
      );

      // Set up message handler
      this.workletNode.port.onmessage = (event) => {
        if (event.data.type === 'audio' && this.onFrameCallback) {
          this.onFrameCallback(event.data.samples, 16000);
        }
      };

      // Create source from media stream
      this.sourceNode = this.audioContext.createMediaStreamSource(stream);

      // Connect source to worklet
      this.sourceNode.connect(this.workletNode);

      // Initialize worklet with configuration
      this.workletNode.port.postMessage({
        type: 'config',
        sampleRate: this.audioContext.sampleRate,
        targetSampleRate: 16000,
        frameSize: 16000,
      });

      this.isInitialized = true;
      console.log('[WakeWorkletNode] Initialized successfully');
    } catch (error) {
      console.error('[WakeWorkletNode] Initialization failed:', error);
      throw error;
    }
  }

  /**
   * Set callback for when audio frames are ready
   */
  setOnFrame(callback: (frame: Float32Array, sampleRate: number) => void): void {
    this.onFrameCallback = callback;
  }

  /**
   * Setup iOS AudioContext resume handlers on user gestures
   */
  private setupIOSResumeHandlers(): void {
    const resumeAudioContext = () => {
      if (this.audioContext.state === 'suspended') {
        this.audioContext.resume().catch((error) => {
          if (import.meta.env.DEV) {
            console.warn('[WakeWorkletNode] Failed to resume AudioContext:', error);
          }
        });
      }
    };

    // Add event listeners for user gestures
    const events = ['click', 'touchstart', 'touchend', 'keydown'];
    events.forEach((event) => {
      const handler = resumeAudioContext;
      document.addEventListener(event, handler, { passive: true });
      this.resumeHandlers.push({ event, handler });
    });
  }

  /**
   * Setup periodic AudioContext resume check (every 15 seconds)
   * Prevents iOS from suspending the context
   */
  private setupPeriodicResume(): void {
    this.resumeInterval = window.setInterval(() => {
      if (this.audioContext.state === 'suspended') {
        this.audioContext.resume().catch((error) => {
          if (import.meta.env.DEV) {
            console.warn('[WakeWorkletNode] Periodic resume failed:', error);
          }
        });
      }
    }, 15000); // Every 15 seconds
  }

  /**
   * Clean up resources
   */
  disconnect(): void {
    // Remove event listeners
    this.resumeHandlers.forEach(({ event, handler }) => {
      document.removeEventListener(event, handler);
    });
    this.resumeHandlers = [];

    // Clear interval
    if (this.resumeInterval !== null) {
      clearInterval(this.resumeInterval);
      this.resumeInterval = null;
    }

    if (this.sourceNode) {
      this.sourceNode.disconnect();
      this.sourceNode = null;
    }

    if (this.workletNode) {
      this.workletNode.port.close();
      this.workletNode.disconnect();
      this.workletNode = null;
    }

    this.isInitialized = false;
    this.onFrameCallback = null;
  }

  /**
   * Check if worklet is initialized
   */
  get initialized(): boolean {
    return this.isInitialized;
  }
}
