/**
 * AudioWorklet Processor for Wake Word Detection
 * 
 * Handles:
 * - Downsampling from 44.1/48kHz to 16kHz
 * - Low-pass anti-aliasing filter
 * - Ring buffer accumulation
 * - Sends 1-second frames (16kHz = 16000 samples) to main thread
 * 
 * Must NOT allocate new arrays inside audio thread - reuse buffers
 */

class WakeWorkletProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    
    // Target sample rate: 16kHz
    this.TARGET_SAMPLE_RATE = 16000;
    
    // Frame size: 1 second at 16kHz = 16000 samples
    this.FRAME_SIZE = 16000;
    
    // Current input sample rate (will be set from processorOptions)
    this.inputSampleRate = 44100; // Default, will be updated
    
    // Downsampling ratio
    this.downsampleRatio = 1;
    
    // Ring buffer for accumulating samples
    this.ringBuffer = new Float32Array(this.FRAME_SIZE);
    this.ringBufferIndex = 0;
    
    // Anti-aliasing filter state (simple IIR low-pass)
    this.filterState = 0;
    this.filterCoeff = 0.95; // Adjust based on downsampling ratio
    
    // Downsampling accumulator
    this.downsampleAccumulator = 0;
    this.downsampleCounter = 0;
    
    // Reusable buffer for downsampled audio
    this.downsampledBuffer = new Float32Array(4096);
    
    // Message handler for initialization
    this.port.onmessage = (event) => {
      if (event.data.type === 'init') {
        this.inputSampleRate = event.data.sampleRate || 44100;
        this.downsampleRatio = this.inputSampleRate / this.TARGET_SAMPLE_RATE;
        
        // Adjust filter coefficient based on downsampling ratio
        if (this.downsampleRatio > 2) {
          this.filterCoeff = 0.98; // Stronger filter for higher ratios
        } else {
          this.filterCoeff = 0.95;
        }
        
        console.log(`[WakeWorklet] Initialized: ${this.inputSampleRate}Hz → ${this.TARGET_SAMPLE_RATE}Hz (ratio: ${this.downsampleRatio.toFixed(2)})`);
      }
    };
  }

  /**
   * Simple low-pass IIR filter for anti-aliasing
   */
  lowPassFilter(sample) {
    this.filterState = this.filterCoeff * this.filterState + (1 - this.filterCoeff) * sample;
    return this.filterState;
  }

  /**
   * Downsample audio using linear interpolation
   */
  downsample(input, inputLength) {
    const outputLength = Math.floor(inputLength / this.downsampleRatio);
    let outputIndex = 0;
    
    for (let i = 0; i < inputLength && outputIndex < outputLength; i++) {
      this.downsampleAccumulator += input[i];
      this.downsampleCounter++;
      
      if (this.downsampleCounter >= this.downsampleRatio) {
        // Apply anti-aliasing filter
        const filtered = this.lowPassFilter(this.downsampleAccumulator / this.downsampleCounter);
        this.downsampledBuffer[outputIndex] = filtered;
        
        outputIndex++;
        this.downsampleAccumulator = 0;
        this.downsampleCounter = 0;
      }
    }
    
    return outputIndex;
  }

  process(inputs, outputs, parameters) {
    // Get input channel (mono)
    const input = inputs[0];
    if (!input || input.length === 0) {
      return true; // Keep processor alive
    }
    
    const inputChannel = input[0];
    if (!inputChannel || inputChannel.length === 0) {
      return true;
    }
    
    // Downsample input to 16kHz
    const downsampledLength = this.downsample(inputChannel, inputChannel.length);
    
    // Accumulate into ring buffer
    for (let i = 0; i < downsampledLength; i++) {
      this.ringBuffer[this.ringBufferIndex] = this.downsampledBuffer[i];
      this.ringBufferIndex++;
      
      // When we have a full frame (1 second), send it to main thread
      if (this.ringBufferIndex >= this.FRAME_SIZE) {
        // Create a copy of the frame (required for transfer)
        const frame = new Float32Array(this.ringBuffer);
        
        // Send frame to main thread
        this.port.postMessage({
          type: 'audioFrame',
          frame: frame,
          sampleRate: this.TARGET_SAMPLE_RATE,
        });
        
        // Reset ring buffer index
        this.ringBufferIndex = 0;
      }
    }
    
    // Keep processor alive
    return true;
  }
}

registerProcessor('wake-worklet-processor', WakeWorkletProcessor);
