/**
 * Wake Word Test Page
 * 
 * Provides comprehensive testing interface:
 * - Live waveform visualization
 * - Live confidence meter
 * - VAD state
 * - Wake detections log
 * - Smooth/unsmoothed values
 * - Config loaded indicator
 */

import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, Mic, MicOff } from 'lucide-react';
import { useWakeWord } from '../hooks/useWakeWord';

interface WakeTestProps {
  onBack?: () => void;
}

export default function WakeTest({ onBack }: WakeTestProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [waveformData] = useState<Float32Array | null>(null);
  const [detections, setDetections] = useState<Array<{ time: number; raw: number; smoothed: number }>>([]);

  const {
    isActive,
    micAccessible,
    vadActive,
    rawConfidence,
    smoothedConfidence,
    smoothingActive,
    threshold,
    onThreshold,
    offThreshold,
    bufferFill,
    error,
    initializing,
    enable,
    disable,
  } = useWakeWord({
    onWakeWordDetected: () => {
      const now = Date.now();
      setDetections((prev) => [
        ...prev.slice(-19), // Keep last 20
        {
          time: now,
          raw: rawConfidence ?? 0,
          smoothed: smoothedConfidence ?? 0,
        },
      ]);
    },
    debounceMs: 2000,
  });

  // Draw waveform
  useEffect(() => {
    if (!canvasRef.current || !waveformData) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Clear
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, width, height);

    // Draw grid
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 10; i++) {
      const y = (height / 10) * i;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Draw waveform
    ctx.strokeStyle = '#60a5fa';
    ctx.lineWidth = 2;
    ctx.beginPath();
    const step = width / waveformData.length;
    for (let i = 0; i < waveformData.length; i++) {
      const x = i * step;
      const y = height / 2 - (waveformData[i] * height) / 2;
      if (i === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    }
    ctx.stroke();
  }, [waveformData]);

  const handleToggle = async () => {
    if (isActive) {
      disable();
    } else {
      try {
        await enable();
      } catch (err) {
        console.error('Failed to enable:', err);
      }
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            {onBack && (
              <button
                onClick={onBack}
                className="p-2 hover:bg-slate-800 rounded-lg transition-colors"
              >
                <ArrowLeft size={24} />
              </button>
            )}
            <h1 className="text-3xl font-bold">Wake Word Test</h1>
          </div>
          <button
            onClick={handleToggle}
            disabled={initializing}
            className={`px-6 py-3 rounded-lg font-medium transition-colors ${
              isActive
                ? 'bg-red-600 hover:bg-red-700 text-white'
                : 'bg-green-600 hover:bg-green-700 text-white disabled:bg-slate-600 disabled:cursor-not-allowed'
            }`}
          >
            {initializing ? (
              'Initializing...'
            ) : isActive ? (
              <>
                <MicOff className="w-5 h-5 inline mr-2" />
                Disable
              </>
            ) : (
              <>
                <Mic className="w-5 h-5 inline mr-2" />
                Enable
              </>
            )}
          </button>
        </div>

        {/* Status Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* System Status */}
          <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
            <h3 className="text-lg font-semibold mb-3">System Status</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-400">Active:</span>
                <span className={isActive ? 'text-green-400' : 'text-slate-500'}>
                  {isActive ? 'Yes' : 'No'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Mic Accessible:</span>
                <span className={micAccessible ? 'text-green-400' : 'text-slate-500'}>
                  {micAccessible ? 'Yes' : 'No'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">VAD:</span>
                <span className={vadActive ? 'text-green-400' : 'text-slate-500'}>
                  {vadActive ? 'Speech' : 'Silence'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Smoothing:</span>
                <span className={smoothingActive ? 'text-purple-400' : 'text-slate-500'}>
                  {smoothingActive ? 'Active' : 'Inactive'}
                </span>
              </div>
              {error && (
                <div className="text-red-400 text-xs mt-2 p-2 bg-red-900/30 rounded">
                  {error}
                </div>
              )}
            </div>
          </div>

          {/* Confidence Values */}
          <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
            <h3 className="text-lg font-semibold mb-3">Confidence</h3>
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-slate-400">Raw:</span>
                  <span className="text-blue-400 font-mono">
                    {rawConfidence !== null ? (rawConfidence * 100).toFixed(1) + '%' : 'N/A'}
                  </span>
                </div>
                <div className="w-full bg-slate-700 rounded-full h-2">
                  <div
                    className="bg-blue-500 h-2 rounded-full transition-all"
                    style={{ width: `${(rawConfidence ?? 0) * 100}%` }}
                  />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-slate-400">Smoothed:</span>
                  <span className="text-purple-400 font-mono">
                    {smoothedConfidence !== null ? (smoothedConfidence * 100).toFixed(1) + '%' : 'N/A'}
                  </span>
                </div>
                <div className="w-full bg-slate-700 rounded-full h-2">
                  <div
                    className="bg-purple-500 h-2 rounded-full transition-all"
                    style={{ width: `${(smoothedConfidence ?? 0) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Thresholds */}
          <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
            <h3 className="text-lg font-semibold mb-3">Thresholds</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-400">Main:</span>
                <span className="text-white font-mono">{threshold?.toFixed(3) ?? 'N/A'}</span>
              </div>
              {onThreshold !== null && (
                <div className="flex justify-between">
                  <span className="text-slate-400">ON:</span>
                  <span className="text-green-400 font-mono">{onThreshold.toFixed(3)}</span>
                </div>
              )}
              {offThreshold !== null && (
                <div className="flex justify-between">
                  <span className="text-slate-400">OFF:</span>
                  <span className="text-yellow-400 font-mono">{offThreshold.toFixed(3)}</span>
                </div>
              )}
              <div className="mt-3 pt-3 border-t border-slate-700">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Buffer fill:</span>
                  <span className={bufferFill >= 1 ? 'text-green-400' : 'text-orange-400 font-mono'}>
                    {Math.round(bufferFill * 100)}%
                  </span>
                </div>
                {import.meta.env.DEV && bufferFill < 1 && (
                  <p className="text-xs text-orange-400 mt-1">Buffer not full — wake word cannot yet trigger</p>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Waveform */}
        <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
          <h3 className="text-lg font-semibold mb-3">Live Waveform</h3>
          <canvas
            ref={canvasRef}
            width={800}
            height={200}
            className="w-full border border-slate-700 rounded"
          />
        </div>

        {/* Detections Log */}
        <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
          <h3 className="text-lg font-semibold mb-3">Recent Detections</h3>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {detections.length === 0 ? (
              <p className="text-slate-400 text-sm">No detections yet...</p>
            ) : (
              detections
                .slice()
                .reverse()
                .map((det, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-slate-900 rounded border border-slate-700 text-sm"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-green-400 font-semibold">✓ Detected</span>
                      <span className="text-slate-400 text-xs">
                        {new Date(det.time).toLocaleTimeString()}
                      </span>
                    </div>
                    <div className="text-slate-400 text-xs">
                      Raw: {det.raw.toFixed(3)}, Smoothed: {det.smoothed.toFixed(3)}
                    </div>
                  </div>
                ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

