import { useState } from 'react';
import { useWakeWord } from '../hooks/useWakeWord';
import { Mic, MicOff, AlertCircle, CheckCircle2, Activity, Clock } from 'lucide-react';

/**
 * Demo component for wake word detection using Hey Buddy! ONNX model
 * 
 * This component demonstrates:
 * - Starting/stopping wake word detection
 * - Displaying listening status
 * - Handling errors and permissions
 * - Using Hey Buddy! model for "Jamie" wake word
 * 
 * Browser Requirements:
 * - Chrome/Edge: Full support
 * - Firefox: Full support  
 * - Safari (iOS/iPadOS): Requires iOS 16.4+ and user gesture
 * 
 * Permissions:
 * - Microphone access will be requested when enabling
 */

export default function WakeWordDemo() {
  const [detectionCount, setDetectionCount] = useState(0);

  const wakeWordState = useWakeWord({
    onWakeWordDetected: () => {
      setDetectionCount(prev => prev + 1);
      // Optional: Add haptic feedback
      if (navigator.vibrate) {
        navigator.vibrate(50);
      }
    },
  });

  const { isActive, micAccessible, vadActive, lastDetection, error, initializing, enable, disable } = wakeWordState;

  const handleToggle = async () => {
    if (initializing) {
      alert('System is still initializing. Please wait...');
      return;
    }
    if (isActive) {
      disable();
    } else {
      try {
        await enable();
      } catch (err) {
        console.error('Failed to enable wake word:', err);
      }
    }
  };

  const formatLastDetection = (timestamp: number | null): string => {
    if (!timestamp) return 'Never';
    const secondsAgo = Math.floor((Date.now() - timestamp) / 1000);
    if (secondsAgo < 60) return `${secondsAgo}s ago`;
    const minutesAgo = Math.floor(secondsAgo / 60);
    if (minutesAgo < 60) return `${minutesAgo}m ago`;
    const hoursAgo = Math.floor(minutesAgo / 60);
    return `${hoursAgo}h ago`;
  };

  return (
    <div className="p-4 bg-slate-800/50 rounded-lg">
      {/* Status Display */}
      <div className="mb-4 p-4 bg-slate-800 rounded-md">
        <div className="flex items-center gap-2 mb-2">
          {isActive ? (
            <CheckCircle2 className="w-5 h-5 text-green-500" />
          ) : (
            <AlertCircle className="w-5 h-5 text-yellow-500" />
          )}
          <span className="text-sm text-slate-300">
            System: {isActive ? 'Active' : initializing ? 'Initializing...' : 'Inactive'}
          </span>
        </div>

        <div className="flex items-center gap-2 mb-2">
          {micAccessible ? (
            <Mic className="w-5 h-5 text-green-500" />
          ) : (
            <MicOff className="w-5 h-5 text-slate-500" />
          )}
          <span className="text-sm text-slate-300">
            Microphone: {micAccessible ? 'Accessible' : 'Not Accessible'}
          </span>
        </div>

        <div className="flex items-center gap-2 mb-2">
          <Activity className={`w-5 h-5 ${vadActive ? 'text-green-500 animate-pulse' : 'text-slate-500'}`} />
          <span className="text-sm text-slate-300">
            VAD: {vadActive ? 'Speech Detected' : 'Listening...'}
          </span>
        </div>

        <div className="flex items-center gap-2 mb-2">
          <Clock className="w-5 h-5 text-slate-500" />
          <span className="text-sm text-slate-300">
            Last Detection: {lastDetection ? formatLastDetection(lastDetection) : 'Never'}
          </span>
        </div>

        {error && (
          <div className="mt-2 p-2 bg-red-900/50 border border-red-700 rounded text-sm text-red-200">
            <AlertCircle className="w-4 h-4 inline mr-1" />
            {error}
          </div>
        )}
      </div>

      {/* Detection Counter */}
      <div className="mb-4 p-3 bg-purple-900/30 rounded-md text-center">
        <div className="text-3xl font-bold text-purple-400">{detectionCount}</div>
        <div className="text-sm text-slate-400">Wake Words Detected</div>
      </div>

      {/* Control Button */}
      <button
        onClick={handleToggle}
        disabled={initializing}
        className={`w-full py-3 px-4 rounded-md font-medium transition-colors ${
          isActive
            ? 'bg-red-600 hover:bg-red-700 text-white'
            : 'bg-green-600 hover:bg-green-700 text-white disabled:bg-slate-600 disabled:cursor-not-allowed'
        }`}
      >
        {initializing ? (
          'Initializing...'
        ) : isActive ? (
          <>
            <MicOff className="w-5 h-5 inline mr-2" />
            Stop Listening
          </>
        ) : (
          <>
            <Mic className="w-5 h-5 inline mr-2" />
            Enable Voice Activation
          </>
        )}
      </button>

      {/* Instructions */}
      <div className="mt-4 p-3 bg-slate-800/50 rounded-md text-xs text-slate-400">
        <p className="mb-1">
          <strong>Instructions:</strong>
        </p>
        <ul className="list-disc list-inside space-y-1">
          <li>Click "Enable Voice Activation" to begin detection</li>
          <li>Grant microphone permission when prompted</li>
          <li>Say <strong>"Jamie"</strong> to activate voice commands</li>
          <li>Detection counter will increment on successful detection</li>
        </ul>
        <p className="mt-2 text-yellow-400">
          <strong>Note:</strong> Uses Hey Buddy! ONNX model for wake word detection.
          Requires microphone permission and works best in quiet environments.
        </p>
      </div>
    </div>
  );
}
