/**
 * React Hook for Wake Word Detection
 * 
 * Complete pipeline:
 * - AudioContext management (iOS-safe)
 * - VAD pre-filtering
 * - AudioWorklet downsampling
 * - ONNX inference
 * - Debounced wake word detection
 * 
 * iOS PWA Requirements:
 * - User gesture activation
 * - Silent audio loop for background execution
 * - AudioContext resume on user interaction
 */

import { useEffect, useRef, useState, useCallback } from 'react';
import { WakeWorkletNode } from '../audio/wakeWorkletNode';
import { VAD } from '../services/vad';
import { WakeInference } from '../services/wakeInference';

type UseWakeWordOptions = {
  /** Callback when wake word "Jamie" is detected */
  onWakeWordDetected: () => void;
  /** Debounce time in milliseconds (default: 2000ms) */
  debounceMs?: number;
};

type WakeWordState = {
  /** Whether wake word system is active */
  isActive: boolean;
  /** Whether microphone is accessible */
  micAccessible: boolean;
  /** Whether VAD is detecting speech */
  vadActive: boolean;
  /** Last wake word detection timestamp */
  lastDetection: number | null;
  /** Error message if any */
  error: string | null;
  /** Whether system is initializing */
  initializing: boolean;
  /** Raw confidence from ONNX model */
  rawConfidence: number | null;
  /** Smoothed confidence (EWMA) */
  smoothedConfidence: number | null;
  /** Whether smoothing is active */
  smoothingActive: boolean;
  /** Current threshold value */
  threshold: number | null;
  /** On threshold for hysteresis */
  onThreshold: number | null;
  /** Off threshold for hysteresis */
  offThreshold: number | null;
  /** Buffer fill ratio (0.0 to 1.0) */
  bufferFill: number;
};

export function useWakeWord({
  onWakeWordDetected,
  debounceMs = 2000,
}: UseWakeWordOptions): WakeWordState & {
  /** Function to enable wake word detection (requires user gesture) */
  enable: () => Promise<void>;
  /** Function to disable wake word detection */
  disable: () => void;
  /** Function to update threshold dynamically */
  setThreshold: (value: number) => void;
  /** Get inference instance (for advanced usage) */
  getInference: () => WakeInference | null;
} {
  const [state, setState] = useState<WakeWordState>({
    isActive: false,
    micAccessible: false,
    vadActive: false,
    lastDetection: null,
    error: null,
    initializing: false,
    rawConfidence: null,
    smoothedConfidence: null,
    smoothingActive: false,
    threshold: null,
    onThreshold: null,
    offThreshold: null,
    bufferFill: 0,
  });

  // Refs for audio pipeline
  const audioContextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const workletNodeRef = useRef<WakeWorkletNode | null>(null);
  const vadRef = useRef<VAD | null>(null);
  const inferenceRef = useRef<WakeInference | null>(null);
  const silentAudioRef = useRef<HTMLAudioElement | null>(null);
  const lastDetectionTimeRef = useRef<number>(0);
  const onWakeWordRef = useRef(onWakeWordDetected);
  const isProcessingRef = useRef<boolean>(false);
  const isActiveRef = useRef<boolean>(false); // Track active state for callback
  
  // Smoothing state refs
  const smoothedConfidenceRef = useRef<number>(0);
  const isDetectedRef = useRef<boolean>(false);
  const smoothingConfigRef = useRef<{ alpha: number; on: number; off: number } | null>(null);

  // Keep callback ref updated
  useEffect(() => {
    onWakeWordRef.current = onWakeWordDetected;
  }, [onWakeWordDetected]);

  /**
   * Initialize silent audio loop for iOS background execution
   */
  const initializeSilentAudio = useCallback(() => {
    if (silentAudioRef.current) {
      return; // Already initialized
    }

    try {
      const silentAudio = new Audio('/silence.mp3');
      silentAudio.loop = true;
      silentAudio.volume = 0;
      silentAudioRef.current = silentAudio;

      // Play silently (required for iOS background execution)
      silentAudio.play().catch((error) => {
        // File might not exist - that's okay, iOS will still work
        if (import.meta.env.DEV) {
          console.warn('[useWakeWord] Silent audio play failed (file may not exist):', error);
          console.info('[useWakeWord] To create silence.mp3, run: ffmpeg -f lavfi -i anullsrc=r=44100:cl=stereo -t 1 -q:a 9 -acodec libmp3lame public/silence.mp3');
        }
      });

      if (import.meta.env.DEV) {
        console.log('[useWakeWord] Silent audio loop initialized');
      }
    } catch (error) {
      // Non-critical - iOS will still work without it
      if (import.meta.env.DEV) {
        console.warn('[useWakeWord] Failed to initialize silent audio (non-critical):', error);
      }
    }
  }, []);

  /**
   * Process audio chunks and feed ring buffer
   */
  const processAudioFrame = useCallback(
    async (samples: Float32Array) => {
      if (!isActiveRef.current || !inferenceRef.current?.initialized) {
        return;
      }

      if (isProcessingRef.current) {
        return; // Skip if already processing
      }

      try {
        // Step 1: Append samples to ring buffer
        inferenceRef.current.appendSamples(samples);

        // Step 2: Check VAD on current chunk (optional - don't block inference)
        let isSpeech = true;
        if (vadRef.current?.initialized) {
          // VAD on current chunk (160 samples = 10ms)
          isSpeech = await vadRef.current.processFrame(samples);
          setState((prev) => ({ ...prev, vadActive: isSpeech }));
        }

        // Step 3: Run inference when buffer is full (VAD is optional - don't block)
        const rawProbability = await inferenceRef.current.maybeRunInference(isSpeech);
        
        if (rawProbability === null) {
          // Buffer not full yet - update buffer fill state
          const bufferFill = inferenceRef.current.getBufferFillRatio();
          setState((prev) => ({ ...prev, bufferFill }));
          return;
        }

        isProcessingRef.current = true;

        // Step 4: Apply EWMA smoothing
        const config = inferenceRef.current.getConfig();
        let smoothedProbability = rawProbability;
        let smoothingActive = false;

        let onThreshold: number;
        let offThreshold: number;
        
        if (config?.smoothing?.method === 'ewma' && smoothingConfigRef.current) {
          const { alpha, on, off } = smoothingConfigRef.current;
          smoothingActive = true;
          onThreshold = on;
          offThreshold = off;

          // EWMA: smoothed = alpha * previous + (1 - alpha) * current
          smoothedConfidenceRef.current = 
            alpha * smoothedConfidenceRef.current + (1 - alpha) * rawProbability;
          smoothedProbability = smoothedConfidenceRef.current;

          // Only log when speech is detected
          if (import.meta.env.DEV && isSpeech) {
            console.log(`[useWakeWord] Speech detected - Raw: ${rawProbability.toFixed(3)}, Smoothed: ${smoothedProbability.toFixed(3)}`);
          }
        } else {
          // No smoothing - use raw value
          smoothedConfidenceRef.current = rawProbability;
          const threshold = inferenceRef.current.getThreshold();
          onThreshold = threshold;
          offThreshold = threshold * 0.7;
        }

        // Step 5: Hysteresis detection (on/off thresholds)
        const threshold = inferenceRef.current.getThreshold();

        let detected = false;
        if (!isDetectedRef.current) {
          // Currently OFF - need to cross ON threshold
          detected = smoothedProbability >= onThreshold;
        } else {
          // Currently ON - need to cross OFF threshold to turn off
          detected = smoothedProbability >= offThreshold;
        }

        isDetectedRef.current = detected;

        // Update state with confidence values and buffer fill
        const bufferFill = inferenceRef.current.getBufferFillRatio();
        setState((prev) => ({
          ...prev,
          rawConfidence: rawProbability,
          smoothedConfidence: smoothedProbability,
          smoothingActive,
          threshold,
          onThreshold,
          offThreshold,
          bufferFill,
        }));

        // Step 6: Check if wake word detected (using smoothed value with hysteresis)
        if (detected && smoothedProbability >= threshold) {
          const now = Date.now();
          const timeSinceLastDetection = now - lastDetectionTimeRef.current;

          // Debounce: only trigger if enough time has passed
          if (timeSinceLastDetection >= debounceMs) {
            lastDetectionTimeRef.current = now;
            setState((prev) => ({ ...prev, lastDetection: now }));
            
            if (import.meta.env.DEV) {
              console.log(`[useWakeWord] WAKE WORD DETECTED! (raw: ${rawProbability.toFixed(3)}, smoothed: ${smoothedProbability.toFixed(3)})`);
            }

            // Trigger callback
            onWakeWordRef.current();
          }
        } else if (import.meta.env.DEV && !detected && isDetectedRef.current) {
          console.log(`[useWakeWord] Wake word OFF (smoothed: ${smoothedProbability.toFixed(3)} < ${offThreshold.toFixed(3)})`);
        }
      } catch (error) {
        console.error('[useWakeWord] Frame processing error:', error);
      } finally {
        isProcessingRef.current = false;
      }
    },
    [debounceMs] // Removed state.isActive from deps since we use ref now
  );

  /**
   * Enable wake word detection (requires user gesture)
   */
  const enable = useCallback(async () => {
    if (state.isActive || state.initializing) {
      return;
    }

    setState((prev) => ({ ...prev, initializing: true, error: null }));

    try {
      // Step 1: Create/resume AudioContext (iOS requirement)
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({
          sampleRate: 44100, // Standard sample rate
        });
      }

      // Resume AudioContext (required after user gesture)
      if (audioContextRef.current.state === 'suspended') {
        await audioContextRef.current.resume();
      }

      // Step 2: Request microphone access
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          sampleRate: 44100,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      streamRef.current = stream;

      // Step 3: Initialize silent audio loop (iOS background hack)
      initializeSilentAudio();

      // Step 4: Clone stream for VAD (web-vad needs its own stream instance)
      const vadStream = stream.clone();
      
      // Step 5: Initialize VAD with cloned stream
      if (!vadRef.current) {
        vadRef.current = new VAD();
        await vadRef.current.initialize(vadStream);
        // Start VAD listening
        await vadRef.current.start();
        if (import.meta.env.DEV) {
          console.log('[useWakeWord] VAD initialized and started');
        }
      }

      // Step 6: Initialize inference
      if (!inferenceRef.current) {
        inferenceRef.current = new WakeInference();
        await inferenceRef.current.initialize();
        
        // Load smoothing config
        const config = inferenceRef.current.getConfig();
        if (config?.smoothing) {
          smoothingConfigRef.current = {
            alpha: config.smoothing.alpha,
            on: config.smoothing.on,
            off: config.smoothing.off,
          };
          smoothedConfidenceRef.current = 0; // Reset smoothed value
          isDetectedRef.current = false; // Reset detection state
          
          // Update state with threshold info
          setState((prev) => ({
            ...prev,
            threshold: config.threshold,
            onThreshold: config.smoothing.on,
            offThreshold: config.smoothing.off,
          }));
          
          if (import.meta.env.DEV) {
            console.log('[useWakeWord] Smoothing config loaded:', smoothingConfigRef.current);
          }
        }
      }

      // Step 7: Initialize AudioWorklet with original stream (for wake word detection)
      if (!workletNodeRef.current) {
        workletNodeRef.current = new WakeWorkletNode(audioContextRef.current);
        await workletNodeRef.current.initialize(stream);
        workletNodeRef.current.setOnFrame(processAudioFrame);
        
        if (import.meta.env.DEV) {
          console.log('[useWakeWord] AudioWorklet initialized and callback set');
        }
      }

      setState((prev) => ({
        ...prev,
        isActive: true,
        micAccessible: true,
        initializing: false,
        error: null,
      }));
      
      // Update ref immediately so callback can use it
      isActiveRef.current = true;

      console.log('[useWakeWord] Wake word detection enabled');
    } catch (error: any) {
      console.error('[useWakeWord] Enable failed:', error);
      setState((prev) => ({
        ...prev,
        isActive: false,
        micAccessible: false,
        initializing: false,
        error: error.message || 'Failed to enable wake word detection',
      }));
    }
  }, [state.isActive, state.initializing, initializeSilentAudio, processAudioFrame]);

  /**
   * Disable wake word detection
   */
  const disable = useCallback(async () => {
    if (!isActiveRef.current) {
      return;
    }
    
    // Update ref immediately to prevent re-entry
    isActiveRef.current = false;

    // Clean up AudioWorklet
    if (workletNodeRef.current) {
      workletNodeRef.current.disconnect();
      workletNodeRef.current = null;
    }

    // Clean up VAD
    if (vadRef.current) {
      await vadRef.current.destroy();
      vadRef.current = null;
    }

    // Clean up inference
    if (inferenceRef.current) {
      await inferenceRef.current.destroy();
      inferenceRef.current = null;
    }

    // Stop media stream
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }

    // Clear resume interval if it exists
    if (audioContextRef.current && (audioContextRef.current as any)._resumeInterval) {
      clearInterval((audioContextRef.current as any)._resumeInterval);
      delete (audioContextRef.current as any)._resumeInterval;
    }

    // Close AudioContext
    if (audioContextRef.current) {
      await audioContextRef.current.close();
      audioContextRef.current = null;
    }

    // Stop silent audio
    if (silentAudioRef.current) {
      // Clear keep-alive interval if it exists
      if ((silentAudioRef.current as any)._keepAliveInterval) {
        clearInterval((silentAudioRef.current as any)._keepAliveInterval);
        delete (silentAudioRef.current as any)._keepAliveInterval;
      }
      silentAudioRef.current.pause();
      silentAudioRef.current = null;
    }

    setState((prev) => ({
      ...prev,
      isActive: false,
      micAccessible: false,
      vadActive: false,
      error: null,
    }));

    console.log('[useWakeWord] Wake word detection disabled');
  }, []); // Remove state.isActive from deps to prevent cleanup effect from re-running

  // Cleanup on unmount only (not when disable function changes)
  useEffect(() => {
    return () => {
      // Only disable if actually active
      if (isActiveRef.current) {
        disable();
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Empty deps - only run on unmount

  // Note: We don't auto-enable/disable based on the enabled prop
  // The component handles enable/disable manually via the enable()/disable() functions
  // This is because enable() requires a user gesture (for microphone access)
  // The enabled prop is just for component state tracking, not for automatic control

  /**
   * Update threshold dynamically
   */
  const setThreshold = useCallback((value: number) => {
    if (inferenceRef.current) {
      inferenceRef.current.setThreshold(value);
      setState((prev) => ({ ...prev, threshold: value }));
      if (import.meta.env.DEV) {
        console.log(`[useWakeWord] Threshold updated to: ${value.toFixed(3)}`);
      }
    }
  }, []);

  /**
   * Get inference instance (for advanced usage)
   */
  const getInference = useCallback(() => {
    return inferenceRef.current;
  }, []);

  return {
    ...state,
    enable,
    disable,
    setThreshold,
    getInference,
  };
}
