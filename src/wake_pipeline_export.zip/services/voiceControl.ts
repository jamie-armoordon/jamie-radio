interface VoiceCommand {
  type: 'play' | 'next' | 'previous' | 'volume_up' | 'volume_down' | 'mute' | 'unmute' | 'whats_playing';
  stationName?: string;
}

interface VoiceControlCallbacks {
  onCommand: (command: VoiceCommand) => void;
  onError?: (error: string) => void;
}

export class VoiceControl {
  private mediaRecorder: MediaRecorder | null = null;
  private audioStream: MediaStream | null = null;
  private callbacks: VoiceControlCallbacks | null = null;
  private isRecordingCommand = false;
  private recordingChunks: Blob[] = [];
  private recordingTimeout: NodeJS.Timeout | null = null;
  private readonly MAX_RECORDING_DURATION = 5000; // 5 seconds max for command
  // Wake word detection is now handled by useWakeWord hook with Hey Buddy! ONNX model

  constructor() {
    // Wake word detection is handled by useWakeWord hook
  }

  /**
   * Start recording command after wake word detection
   * This is called by the wake word detection system (useWakeWord hook)
   */
  public async startCommandRecording(): Promise<void> {
    if (this.isRecordingCommand) return;
    
    this.isRecordingCommand = true;
    
    // Wake word detection is handled by useWakeWord hook
    // No need to stop/restart here

    try {
      // Request microphone access (reuse if already available)
      if (!this.audioStream) {
        this.audioStream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
        });
      }

      // Create MediaRecorder
      const options: MediaRecorderOptions = {
        mimeType: 'audio/webm;codecs=opus',
      };

      // Fallback to default if webm not supported
      if (!MediaRecorder.isTypeSupported(options.mimeType!)) {
        options.mimeType = 'audio/webm';
      }

      this.mediaRecorder = new MediaRecorder(this.audioStream, options);
      this.recordingChunks = [];

      this.mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          this.recordingChunks.push(event.data);
        }
      };

      this.mediaRecorder.onstop = async () => {
        this.isRecordingCommand = false;
        
        if (this.recordingChunks.length === 0) {
          // Wake word detection is handled by useWakeWord hook
          return;
        }

        // Combine all chunks into a single blob
        const audioBlob = new Blob(this.recordingChunks, { type: this.mediaRecorder?.mimeType || 'audio/webm' });
        
        // Convert to base64 for API
        const reader = new FileReader();
        reader.onloadend = async () => {
          const base64Audio = (reader.result as string).split(',')[1];
          
          // Send to AI API for audio understanding (only after wake word detected)
          try {
            const response = await fetch('/api/ai-audio', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                audio: base64Audio,
                mimeType: this.mediaRecorder?.mimeType || 'audio/webm',
              }),
            });

            if (!response.ok) {
              throw new Error(`AI API error: ${response.status}`);
            }

            const result = await response.json();
            
            // Parse command from AI response (Gemini returns structured JSON)
            if (result.command && this.callbacks) {
              // Speak the response text if available (from AI)
              if (result.text && 'speechSynthesis' in window) {
                const utterance = new SpeechSynthesisUtterance(result.text);
                utterance.lang = 'en-GB';
                window.speechSynthesis.speak(utterance);
              }

              // Map AI command to VoiceCommand type
              let commandType: VoiceCommand['type'] = 'whats_playing';
              
              if (result.command === 'play') {
                commandType = 'play';
              } else if (result.command === 'next') {
                commandType = 'next';
              } else if (result.command === 'previous') {
                commandType = 'previous';
              } else if (result.command === 'volume') {
                commandType = result.action === 'up' ? 'volume_up' : 'volume_down';
              } else if (result.command === 'mute') {
                commandType = 'mute';
              } else if (result.command === 'unmute') {
                commandType = 'unmute';
              } else if (result.command === 'info') {
                commandType = 'whats_playing';
              }

              const command: VoiceCommand = {
                type: commandType,
                stationName: result.station,
              };
              this.callbacks.onCommand(command);
            }
          } catch (error) {
            console.error('Failed to process audio:', error);
            if (this.callbacks?.onError) {
              this.callbacks.onError('Failed to process audio');
            }
          }

          // Wake word detection is handled by useWakeWord hook
        };

        reader.readAsDataURL(audioBlob);
      };

      // Start recording
      this.mediaRecorder.start();
      
      // Set max recording duration
      this.recordingTimeout = setTimeout(() => {
        this.stopCommandRecording();
      }, this.MAX_RECORDING_DURATION);

    } catch (error: any) {
      console.error('Failed to start recording:', error);
      this.isRecordingCommand = false;
      if (this.callbacks?.onError) {
        this.callbacks.onError(error.message || 'Failed to access microphone');
      }
      // Wake word detection is handled by useWakeWord hook
    }
  }

  private stopCommandRecording(): void {
    if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
      this.mediaRecorder.stop();
    }
    
    if (this.recordingTimeout) {
      clearTimeout(this.recordingTimeout);
      this.recordingTimeout = null;
    }
  }

  public start(callbacks: VoiceControlCallbacks) {
    this.callbacks = callbacks;
    // Wake word detection is handled by useWakeWord hook
    // This method is kept for compatibility but doesn't start wake word detection
  }

  public stop() {
    this.isRecordingCommand = false;
    this.stopCommandRecording();
    if (this.audioStream) {
      this.audioStream.getTracks().forEach(track => track.stop());
      this.audioStream = null;
    }
  }

  public isSupported(): boolean {
    // Check for MediaRecorder support for command recording
    const hasMediaRecorder = typeof navigator !== 'undefined' &&
                             !!navigator.mediaDevices?.getUserMedia &&
                             'MediaRecorder' in window &&
                             typeof (window as any).MediaRecorder === 'function' &&
                             typeof (window as any).MediaRecorder.isTypeSupported === 'function';
    // Wake word detection is handled by useWakeWord hook with Hey Buddy! ONNX
    return hasMediaRecorder;
  }
}

// Singleton instance
let voiceControlInstance: VoiceControl | null = null;

export function getVoiceControl(): VoiceControl {
  if (!voiceControlInstance) {
    voiceControlInstance = new VoiceControl();
  }
  return voiceControlInstance;
}
