/**
 * Wake Word Inference Service
 * 
 * Handles ONNX model loading and inference for wake word detection
 * Uses Hey Buddy! model (jamie_noise_robust.onnx) - expects 1s PCM at 16kHz, outputs probability [0..1]
 */

import * as ort from 'onnxruntime-web';

type WakeConfig = {
  threshold: number;
  smoothing: {
    method: string;
    alpha: number;
    on: number;
    off: number;
  };
};

const TARGET_RATE = 16000;
const WINDOW_SIZE = TARGET_RATE * 1; // 1 second = 16000 samples

export class WakeInference {
  private session: ort.InferenceSession | null = null;
  private isInitialized = false;
  private readonly MODEL_PATH = '/models/jamie_noise_robust.onnx';
  private readonly CONFIG_PATH = '/models/wake_config.json';
  private threshold: number = 0.85; // Wake word detection threshold (configurable)
  private config: WakeConfig | null = null;
  
  // Ring buffer for 1-second rolling window
  private ringBuffer = new Float32Array(WINDOW_SIZE);
  private ringPos = 0;
  private bufferFilled = false;
  private inferenceCallback: ((probability: number) => void) | null = null;

  /**
   * Load configuration from wake_config.json
   */
  private async loadConfig(): Promise<WakeConfig> {
    try {
      const response = await fetch(this.CONFIG_PATH);
      if (!response.ok) {
        throw new Error(`Failed to load config: ${response.statusText}`);
      }
      const config: WakeConfig = await response.json();
      this.config = config;
      this.threshold = config.threshold;
      
      if (import.meta.env.DEV) {
        console.log('[WakeInference] Config loaded:', config);
      }
      
      return config;
    } catch (error) {
      console.warn('[WakeInference] Failed to load config, using defaults:', error);
      // Use default config
      const defaultConfig: WakeConfig = {
        threshold: 0.85,
        smoothing: {
          method: 'ewma',
          alpha: 0.35,
          on: 0.50,
          off: 0.35,
        },
      };
      this.config = defaultConfig;
      this.threshold = defaultConfig.threshold;
      return defaultConfig;
    }
  }

  /**
   * Initialize ONNX Runtime and load model
   * Must be called after user gesture (iOS requirement)
   */
  async initialize(): Promise<void> {
    if (this.isInitialized) {
      return;
    }

    try {
      // Load config first
      await this.loadConfig();

      // Configure ONNX Runtime for WASM backend
      // Use string path (simpler and works better)
      ort.env.wasm.wasmPaths = '/ort-wasm/';
      ort.env.wasm.numThreads = 1; // Single-thread mode for iOS
      ort.env.wasm.simd = true; // Enable SIMD if available

      console.log('[WakeInference] Loading ONNX model from:', this.MODEL_PATH);

      // Load model
      this.session = await ort.InferenceSession.create(this.MODEL_PATH, {
        executionProviders: ['wasm'], // WASM backend only
        graphOptimizationLevel: 'all',
      });

      // Log model input/output info with shapes
      const inputNames = this.session.inputNames;
      const outputNames = this.session.outputNames;
      const inputMetadata = this.session.inputMetadata;
      const outputMetadata = this.session.outputMetadata;
      
      // Extract shapes safely
      const inputShapes: Record<string, number[]> = {};
      const outputShapes: Record<string, number[]> = {};
      
      for (const [name, meta] of Object.entries(inputMetadata)) {
        if ('dims' in meta && Array.isArray((meta as any).dims)) {
          inputShapes[name] = (meta as any).dims;
        }
      }
      
      for (const [name, meta] of Object.entries(outputMetadata)) {
        if ('dims' in meta && Array.isArray(meta.dims)) {
          outputShapes[name] = meta.dims;
        }
      }
      
      console.log('[WakeInference] Model loaded:', {
        inputs: inputNames,
        outputs: outputNames,
        inputShapes,
        outputShapes,
      });

      this.isInitialized = true;
      console.log('[WakeInference] Initialized successfully');
    } catch (error) {
      console.error('[WakeInference] Initialization failed:', error);
      throw error;
    }
  }

  /**
   * Append samples to ring buffer
   * @param samples Float32Array of 16kHz PCM samples (typically 160 samples = 10ms)
   */
  appendSamples(samples: Float32Array): void {
    const n = samples.length;

    if (this.ringPos + n < WINDOW_SIZE) {
      this.ringBuffer.set(samples, this.ringPos);
      this.ringPos += n;
    } else {
      const first = WINDOW_SIZE - this.ringPos;
      this.ringBuffer.set(samples.subarray(0, first), this.ringPos);
      const remaining = n - first;
      this.ringBuffer.set(samples.subarray(first, first + remaining), 0);
      this.ringPos = remaining;
      this.bufferFilled = true;
    }
  }

  /**
   * Get buffer fill ratio (0.0 to 1.0)
   */
  getBufferFillRatio(): number {
    return this.bufferFilled ? 1.0 : this.ringPos / WINDOW_SIZE;
  }

  /**
   * Set callback for inference results
   */
  setInferenceCallback(callback: (probability: number) => void): void {
    this.inferenceCallback = callback;
  }

  /**
   * Preprocess audio buffer to match training pipeline exactly
   * 
   * Training preprocessing:
   * 1. RMS normalize: audio = audio / rms (where rms = sqrt(mean(audio**2)))
   * 2. Pad/center-crop to exactly 16000 samples
   * 3. Convert to float32
   * 
   * @param buffer Raw audio buffer (may be > or < 16000 samples)
   * @returns Preprocessed buffer exactly 16000 samples, RMS normalized
   */
  private preprocessBuffer(buffer: Float32Array): Float32Array {
    // Step 1: Pad or center-crop to exactly 16000 samples (matches training)
    let processed: Float32Array;
    
    if (buffer.length > WINDOW_SIZE) {
      // Center crop: take middle 16000 samples
      const start = Math.floor((buffer.length - WINDOW_SIZE) / 2);
      processed = buffer.subarray(start, start + WINDOW_SIZE);
    } else if (buffer.length < WINDOW_SIZE) {
      // Pad at end with zeros
      processed = new Float32Array(WINDOW_SIZE);
      processed.set(buffer, 0);
      // Remainder is already zeros
    } else {
      // Exactly 16000 samples
      processed = buffer;
    }
    
    // Step 2: RMS normalization (matches training: audio = audio / rms)
    const normalized = new Float32Array(WINDOW_SIZE);
    
    // Calculate RMS: sqrt(mean(audio**2))
    let sumSquares = 0;
    for (let i = 0; i < processed.length; i++) {
      sumSquares += processed[i] * processed[i];
    }
    const rms = Math.sqrt(sumSquares / processed.length);
    
    // Normalize: audio = audio / rms
    if (rms > 0.0001) {
      // Avoid division by zero
      for (let i = 0; i < processed.length; i++) {
        normalized[i] = processed[i] / rms;
      }
    } else {
      // Silence - return zeros
      normalized.fill(0);
    }
    
    return normalized;
  }

  /**
   * Run inference if buffer is full
   * Matches training preprocessing exactly: RMS normalization + pad/crop
   * @param isSpeech Whether VAD detected speech (for logging)
   */
  async maybeRunInference(isSpeech: boolean = true): Promise<number | null> {
    if (!this.bufferFilled) {
      return null; // Prevent tiny-frame inference
    }

    if (!this.session || !this.isInitialized) {
      return null;
    }

    try {
      const startTime = performance.now();

      // Step 1: Preprocess buffer (RMS normalize + pad/crop to exactly 16000)
      const preprocessedBuffer = this.preprocessBuffer(this.ringBuffer);

      // Step 2: Calculate RMS for debug logging
      let rmsBefore = 0;
      if (import.meta.env.DEV && isSpeech) {
        let sumSquares = 0;
        for (let i = 0; i < this.ringBuffer.length; i++) {
          sumSquares += this.ringBuffer[i] * this.ringBuffer[i];
        }
        rmsBefore = Math.sqrt(sumSquares / this.ringBuffer.length);
      }

      // Step 3: Get expected input shape from model metadata
      const inputName = this.session.inputNames[0];
      let inputShape: number[] = [1, 16000];
      try {
        const inputMeta = (this.session.inputMetadata as any)[inputName];
        if (inputMeta && inputMeta.dims && Array.isArray(inputMeta.dims)) {
          inputShape = inputMeta.dims;
        }
      } catch (e) {
        // Use default shape if metadata access fails
      }
      
      // Step 4: Create input tensor with correct shape
      // Training uses [1, 1, 16000] or [1, 16000]
      let inputTensor: ort.Tensor;
      if (inputShape.length === 3 && inputShape[2] === 16000) {
        // Shape [1, 1, 16000] - preferred for training compatibility
        inputTensor = new ort.Tensor('float32', preprocessedBuffer, [1, 1, 16000]);
      } else if (inputShape.length === 2 && inputShape[1] === 16000) {
        // Shape [1, 16000]
        inputTensor = new ort.Tensor('float32', preprocessedBuffer, [1, 16000]);
      } else {
        // Fallback: try [1, 1, 16000] first (most common for audio models)
        inputTensor = new ort.Tensor('float32', preprocessedBuffer, [1, 1, 16000]);
      }

      // Step 5: Debug logging (comprehensive)
      if (import.meta.env.DEV && isSpeech) {
        const bufferFillPercent = Math.round(this.getBufferFillRatio() * 100);
        console.log(`[WakeInference] ===== Inference Debug =====`);
        console.log(`[WakeInference] Buffer fill: ${bufferFillPercent}%`);
        console.log(`[WakeInference] RMS before normalization: ${rmsBefore.toFixed(6)}`);
        console.log(`[WakeInference] First 10 preprocessed samples: [${Array.from(preprocessedBuffer.slice(0, 10)).map(v => v.toFixed(6)).join(', ')}]`);
        console.log(`[WakeInference] Input tensor shape: [${inputTensor.dims.join(', ')}]`);
      }

      // Step 6: Run inference
      const feeds = { [inputName]: inputTensor };
      const results = await this.session.run(feeds);

      // Step 7: Extract probability from output
      const outputName = this.session.outputNames[0];
      const output = results[outputName];
      
      // Step 8: Comprehensive output logging
      if (import.meta.env.DEV && isSpeech) {
        console.log(`[WakeInference] Output shape: [${output.dims.join(', ')}], size: ${output.data.length}`);
        const outputArray = Array.from(output.data as Float32Array);
        if (outputArray.length <= 10) {
          console.log(`[WakeInference] Output values: [${outputArray.map(v => v.toFixed(6)).join(', ')}]`);
        } else {
          console.log(`[WakeInference] Output values (first 10): [${outputArray.slice(0, 10).map(v => v.toFixed(6)).join(', ')}]`);
        }
      }
      
      // Step 9: Extract probability based on output shape
      let probability: number;
      if (output.dims.length === 0 || (output.dims.length === 1 && output.dims[0] === 1)) {
        // Scalar output
        probability = output.data[0] as number;
      } else if (output.dims.length === 1 && output.dims[0] === 2) {
        // Binary classification [negative, positive]
        const outputArray = output.data as Float32Array;
        probability = outputArray[1] as number;
      } else if (output.dims.length === 2 && output.dims[1] === 1) {
        // Shape [1, 1]
        probability = output.data[0] as number;
      } else if (output.dims.length === 2 && output.dims[1] === 2) {
        // Shape [1, 2] - take the positive class
        const outputArray = output.data as Float32Array;
        probability = outputArray[1] as number;
      } else {
        // Fallback: take first value
        probability = output.data[0] as number;
      }

      const inferenceTime = performance.now() - startTime;
      
      // Step 10: Final result logging
      if (import.meta.env.DEV && isSpeech) {
        console.log(`[WakeInference] Probability: ${probability.toFixed(6)} (${inferenceTime.toFixed(1)}ms)`);
        console.log(`[WakeInference] =========================`);
      }

      // Call callback if set
      if (this.inferenceCallback) {
        this.inferenceCallback(probability);
      }

      return probability;
    } catch (error) {
      console.error('[WakeInference] Inference error:', error);
      return null;
    }
  }

  /**
   * Run inference on audio frame (legacy method - kept for compatibility)
   * @param audioFrame Float32Array of 16kHz PCM audio (1 second = 16000 samples)
   * @param isSpeech Whether VAD detected speech (for logging)
   * @returns Promise<number> Probability score [0..1]
   */
  async infer(audioFrame: Float32Array, isSpeech: boolean = true): Promise<number> {
    if (!this.session || !this.isInitialized) {
      throw new Error('WakeInference not initialized');
    }

    if (audioFrame.length !== 16000) {
      console.warn(`[WakeInference] Expected 16000 samples, got ${audioFrame.length}`);
      // Pad or truncate if needed
      const padded = new Float32Array(16000);
      const copyLength = Math.min(audioFrame.length, 16000);
      padded.set(audioFrame.subarray(0, copyLength));
      return this.infer(padded, isSpeech);
    }

    try {
      const startTime = performance.now();

      // Get expected input shape from model metadata
      const inputName = this.session.inputNames[0];
      // Try to get shape from metadata, default to [1, 16000]
      let inputShape: number[] = [1, 16000];
      try {
        const inputMeta = (this.session.inputMetadata as any)[inputName];
        if (inputMeta && inputMeta.dims && Array.isArray(inputMeta.dims)) {
          inputShape = inputMeta.dims;
        }
      } catch (e) {
        // Use default shape if metadata access fails
      }
      
      // Create input tensor with correct shape
      let inputTensor: ort.Tensor;
      if (inputShape.length === 2 && inputShape[1] === 16000) {
        // Shape: [batch, samples] = [1, 16000]
        inputTensor = new ort.Tensor('float32', audioFrame, [1, 16000]);
      } else if (inputShape.length === 3 && inputShape[2] === 16000) {
        // Shape: [batch, channels, samples] = [1, 1, 16000]
        inputTensor = new ort.Tensor('float32', audioFrame, [1, 1, 16000]);
      } else {
        // Fallback: use [1, 16000]
        console.warn(`[WakeInference] Unexpected input shape: ${inputShape.join(', ')}, using [1, 16000]`);
        inputTensor = new ort.Tensor('float32', audioFrame, [1, 16000]);
      }

      // Run inference
      const feeds = { [inputName]: inputTensor };
      const results = await this.session.run(feeds);

      // Extract probability from output
      const outputName = this.session.outputNames[0];
      const output = results[outputName];
      
      // Handle different output shapes
      let probability: number;
      if (output.dims.length === 0 || (output.dims.length === 1 && output.dims[0] === 1)) {
        // Scalar or [1] shape
        probability = output.data[0] as number;
      } else if (output.dims.length === 1 && output.dims[0] === 2) {
        // Binary classification [not_jamie, jamie] - take second value
        const outputArray = output.data as Float32Array;
        probability = outputArray[1] as number;
      } else {
        // Take first value as fallback
        probability = output.data[0] as number;
      }

      const inferenceTime = performance.now() - startTime;
      
      // Only log when speech is detected
      if (import.meta.env.DEV && isSpeech) {
        console.log(`[WakeInference] Speech detected - Probability: ${probability.toFixed(3)} (${inferenceTime.toFixed(1)}ms)`);
      }

      return probability;
    } catch (error) {
      console.error('[WakeInference] Inference error:', error);
      throw error;
    }
  }

  /**
   * Check if wake word is detected
   * @param probability Probability score from inference
   * @returns boolean
   */
  isWakeWordDetected(probability: number): boolean {
    return probability >= this.threshold;
  }

  /**
   * Get detection threshold
   */
  getThreshold(): number {
    return this.threshold;
  }

  /**
   * Set detection threshold dynamically
   */
  setThreshold(value: number): void {
    if (value < 0 || value > 1) {
      throw new Error('Threshold must be between 0 and 1');
    }
    this.threshold = value;
    if (import.meta.env.DEV) {
      console.log(`[WakeInference] Threshold updated to: ${value.toFixed(3)}`);
    }
  }

  /**
   * Get full configuration
   */
  getConfig(): WakeConfig | null {
    return this.config;
  }

  /**
   * Clean up resources
   */
  async destroy(): Promise<void> {
    if (this.session) {
      // ONNX Runtime doesn't have explicit destroy, but we can null the reference
      this.session = null;
    }
    this.isInitialized = false;
  }

  /**
   * Check if inference is initialized
   */
  get initialized(): boolean {
    return this.isInitialized;
  }
}
