/**
 * Voice Activity Detection (VAD) Wrapper
 * 
 * Uses web-vad (Vite-compatible fork) for efficient speech detection
 * Only passes audio frames to wake word inference when speech is detected
 * 
 * Expected reduction: 70-80% CPU usage
 */

import { VAD as WebVAD } from 'web-vad';
import * as ort from 'onnxruntime-web';

export class VAD {
  private vad: WebVAD | null = null;
  private isInitialized = false;
  private onSpeechCallback: ((isSpeech: boolean) => void) | null = null;
  private isSpeechActive = false; // Track current speech state
  private mediaStream: MediaStream | null = null;

  /**
   * Initialize VAD with a media stream
   */
  async initialize(stream?: MediaStream): Promise<void> {
    if (this.isInitialized) {
      return;
    }

    try {
      // Configure ONNX Runtime for VAD (uses WASM backend)
      ort.env.wasm.wasmPaths = '/ort-wasm/';
      ort.env.wasm.numThreads = 1;
      ort.env.wasm.simd = true;

      // Get or use provided media stream
      if (!stream) {
        stream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
        });
      }
      this.mediaStream = stream;

      // Create VAD instance with web-vad (Vite-compatible)
      this.vad = new WebVAD({
        workletURL: '/worklet.js',
        modelUrl: '/silero_vad.onnx', // Model should be copied to public root
        stream: this.mediaStream,
        onSpeechStart: () => {
          this.isSpeechActive = true;
          if (import.meta.env.DEV) {
            console.log('[VAD] Speech started!');
          }
          if (this.onSpeechCallback) {
            this.onSpeechCallback(true);
          }
        },
        onSpeechEnd: () => {
          this.isSpeechActive = false;
          if (import.meta.env.DEV) {
            console.log('[VAD] Speech ended');
          }
          if (this.onSpeechCallback) {
            this.onSpeechCallback(false);
          }
        },
        onVADMisfire: () => {
          // Handle false positives if needed
        },
      });

      await this.vad.init();
      this.isInitialized = true;
      console.log('[VAD] Initialized successfully');
    } catch (error) {
      console.error('[VAD] Initialization failed:', error);
      throw error;
    }
  }

  /**
   * Process audio frame and return speech detection result
   * Gates ONNX inference - only returns true when speech is detected
   * @param _audioFrame Float32Array of 16kHz PCM audio (unused - MicVAD processes internally)
   * @returns Promise<boolean> true if speech detected (gate inference)
   * 
   * Note: MicVAD processes audio internally via AudioWorklet
   * This method gates inference based on speech state tracked by callbacks
   */
  async processFrame(_audioFrame: Float32Array): Promise<boolean> {
    if (!this.vad || !this.isInitialized) {
      // If VAD not initialized, pass all frames (fallback)
      return true;
    }

    try {
      // Gate inference based on speech state
      // Only run ONNX inference when speech is detected (battery optimization)
      return this.isSpeechActive;
    } catch (error) {
      console.error('[VAD] Processing error:', error);
      // On error, pass frame through (fail open)
      return true;
    }
  }
  
  /**
   * Get current speech state
   */
  get speechActive(): boolean {
    return this.isSpeechActive;
  }

  /**
   * Set callback for speech start/end events
   */
  setOnSpeech(callback: (isSpeech: boolean) => void): void {
    this.onSpeechCallback = callback;
  }

  /**
   * Start VAD processing
   */
      async start(): Promise<void> {
        if (this.vad && this.isInitialized) {
          this.vad.start();
          if (import.meta.env.DEV) {
            console.log('[VAD] Started listening');
          }
        }
      }

  /**
   * Stop VAD processing
   */
  async stop(): Promise<void> {
    if (this.vad && this.isInitialized) {
      this.vad.pause();
    }
  }

  /**
   * Clean up resources
   */
  async destroy(): Promise<void> {
    if (this.vad) {
      this.vad.pause();
      this.vad.destroy();
      this.vad = null;
    }
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach(track => track.stop());
      this.mediaStream = null;
    }
    this.isInitialized = false;
    this.onSpeechCallback = null;
  }

  /**
   * Check if VAD is initialized
   */
  get initialized(): boolean {
    return this.isInitialized;
  }
}
