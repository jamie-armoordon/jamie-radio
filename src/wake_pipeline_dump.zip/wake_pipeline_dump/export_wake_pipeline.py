# Run this with: python export_wake_pipeline.py
# It will create: wake_pipeline_export.zip

import os
import zipfile

# Filenames we MUST extract
TARGET_FILES = {
    "wakeInference.ts",
    "useWakeWord.ts",
    "WakeWordProcessor.worklet.js",
    "WakeWordDemo.tsx",
    "vad.ts",
    "voiceControl.ts",
    "voiceCommandAI.ts",
    "voiceFeedback.ts",
}

# Also include ANY file whose name contains "wake"
WAKE_KEYWORDS = ["wake"]

OUTPUT_ZIP = "wake_pipeline_export.zip"

def should_include(filename: str) -> bool:
    base = os.path.basename(filename).lower()
    if base in (name.lower() for name in TARGET_FILES):
        return True
    return any(keyword in base for keyword in WAKE_KEYWORDS)

def collect_files(root: str):
    collected = []
    for dirpath, dirs, files in os.walk(root):
        for f in files:
            full_path = os.path.join(dirpath, f)
            if should_include(full_path):
                collected.append(full_path)
    return collected

def main():
    root = os.getcwd()  # run from project root or /src
    print(f"🔍 Scanning project: {root}")

    files = collect_files(root)
    if not files:
        print("❌ No wake-word files found.")
        return

    print(f"📁 Found {len(files)} files:")
    for f in files:
        print(" →", f)

    print(f"\n📦 Writing ZIP: {OUTPUT_ZIP}")
    with zipfile.ZipFile(OUTPUT_ZIP, "w", zipfile.ZIP_DEFLATED) as zipf:
        for f in files:
            arcname = os.path.relpath(f, root)
            zipf.write(f, arcname)

    print("\n✅ Export complete!")
    print(f"📦 Created: {OUTPUT_ZIP}")
    print("📤 Upload this ZIP here in ChatGPT.")

if __name__ == "__main__":
    main()
