/**
 * Wake Word Settings Component
 * 
 * Simple controls:
 * - Enable/Disable
 * - Threshold slider
 * - Test button with visual indicator
 */

import { useState, useEffect, useRef } from 'react';
import { Sliders, Mic, MicOff, Radio } from 'lucide-react';
import { useWakeWord } from '../../hooks/useWakeWord';

interface WakeWordSettingsProps {
  onWakeWordDetected?: () => void;
}

export default function WakeWordSettings({ onWakeWordDetected }: WakeWordSettingsProps) {
  const [threshold, setThreshold] = useState<number>(0.85);
  const [testActive, setTestActive] = useState(false);
  const [testDetected, setTestDetected] = useState(false);
  const testTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const {
    isActive,
    threshold: currentThreshold,
    initializing,
    error,
    setThreshold: updateThreshold,
    enable,
    disable,
  } = useWakeWord({
    onWakeWordDetected: () => {
      // Handle test mode
      if (testActive) {
        setTestDetected(true);
        // Clear any existing timeout
        if (testTimeoutRef.current) {
          clearTimeout(testTimeoutRef.current);
        }
        // Reset after 2 seconds
        testTimeoutRef.current = setTimeout(() => {
          setTestDetected(false);
        }, 2000);
      }
      // Also call the original callback
      onWakeWordDetected?.();
    },
    debounceMs: 2000,
  });

  // Sync threshold with current value
  useEffect(() => {
    if (currentThreshold !== null) {
      setThreshold(currentThreshold);
    }
  }, [currentThreshold]);

  // Cleanup test timeout
  useEffect(() => {
    return () => {
      if (testTimeoutRef.current) {
        clearTimeout(testTimeoutRef.current);
      }
    };
  }, []);

  const handleThresholdChange = (value: number) => {
    setThreshold(value);
    updateThreshold(value);
  };

  const handleToggle = async () => {
    if (isActive) {
      disable();
      setTestActive(false);
      setTestDetected(false);
    } else {
      try {
        await enable();
      } catch (err) {
        console.error('Failed to enable wake word:', err);
      }
    }
  };

  const handleTestToggle = () => {
    if (!isActive) {
      // Enable first if not active
      enable().catch((err) => {
        console.error('Failed to enable wake word:', err);
      });
    }
    setTestActive(!testActive);
    setTestDetected(false);
  };

  return (
    <div className="space-y-4">
      {/* Enable/Disable Button */}
      <div className="flex items-center justify-between p-4 bg-slate-800 rounded-lg border border-slate-700">
        <div>
          <h4 className="text-sm font-semibold text-white mb-1">Wake Word Detection</h4>
          <p className="text-xs text-slate-400">
            {isActive ? 'System is active and listening' : 'Click to enable wake word detection'}
          </p>
        </div>
        <button
          onClick={handleToggle}
          disabled={initializing}
          className={`px-4 py-2 rounded-lg font-medium transition-colors ${
            isActive
              ? 'bg-red-600 hover:bg-red-700 text-white'
              : 'bg-green-600 hover:bg-green-700 text-white disabled:bg-slate-600 disabled:cursor-not-allowed'
          }`}
        >
          {initializing ? (
            'Initializing...'
          ) : isActive ? (
            <>
              <MicOff className="w-4 h-4 inline mr-2" />
              Disable
            </>
          ) : (
            <>
              <Mic className="w-4 h-4 inline mr-2" />
              Enable
            </>
          )}
        </button>
      </div>

      {error && (
        <div className="p-3 bg-red-900/30 border border-red-700 rounded-lg text-sm text-red-200">
          {error}
        </div>
      )}

      {/* Threshold Slider */}
      <div className="space-y-2 p-4 bg-slate-800 rounded-lg border border-slate-700">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-slate-400" />
            <span className="text-sm font-semibold text-white">Detection Threshold</span>
          </div>
          <span className="text-sm text-slate-300 font-mono">{threshold.toFixed(2)}</span>
        </div>
        <input
          type="range"
          min="0.5"
          max="0.95"
          step="0.01"
          value={threshold}
          onChange={(e) => handleThresholdChange(Number.parseFloat(e.target.value))}
          className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-purple-500"
        />
        <div className="flex items-center justify-between text-xs text-slate-500 mt-1">
          <span>0.50</span>
          <span>0.95</span>
        </div>
      </div>

      {/* Test Button */}
      <div className="p-4 bg-slate-800 rounded-lg border border-slate-700">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h4 className="text-sm font-semibold text-white mb-1">Test Detection</h4>
            <p className="text-xs text-slate-400">Say "Jamie" to test wake word detection</p>
          </div>
          <button
            onClick={handleTestToggle}
            disabled={initializing}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              testActive
                ? 'bg-purple-600 hover:bg-purple-700 text-white'
                : 'bg-slate-700 hover:bg-slate-600 text-white disabled:bg-slate-600 disabled:cursor-not-allowed'
            }`}
          >
            {testActive ? 'Stop Test' : 'Start Test'}
          </button>
        </div>
        
        {/* Visual Indicator (Discord-style) */}
        <div className="flex items-center justify-center py-6">
          <div className="relative">
            <div
              className={`w-24 h-24 rounded-full transition-all duration-300 ${
                testDetected
                  ? 'bg-green-500 shadow-lg shadow-green-500/50 scale-110'
                  : testActive
                  ? 'bg-slate-600 animate-pulse'
                  : 'bg-slate-700'
              }`}
            />
            {testActive && !testDetected && (
              <div className="absolute inset-0 flex items-center justify-center">
                <Radio className="w-8 h-8 text-white/50" />
              </div>
            )}
            {testDetected && (
              <div className="absolute inset-0 flex items-center justify-center">
                <Mic className="w-10 h-10 text-white" />
              </div>
            )}
          </div>
        </div>
        
        {testActive && (
          <p className="text-center text-xs text-slate-400 mt-2">
            {testDetected ? '✓ "Jamie" detected!' : 'Listening... Say "Jamie"'}
          </p>
        )}
      </div>
    </div>
  );
}

