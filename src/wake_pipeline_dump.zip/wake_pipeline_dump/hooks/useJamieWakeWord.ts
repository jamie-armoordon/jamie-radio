/**
 * High-level hook for Jamie wake word detection
 * Wraps useWakeWord with additional features for voice commands
 */

import { useCallback, useEffect, useState, useRef } from 'react';
import { useWakeWord } from './useWakeWord';

type VoiceCommand = {
  intent: 'play' | 'volume' | 'next' | 'previous' | 'stop' | 'unknown';
  station?: string;
  volumeLevel?: number;
  volumeAction?: 'up' | 'down' | 'set';
};

type UseJamieWakeWordOptions = {
  /** Callback when wake word is detected */
  onWakeWordDetected?: () => void;
  /** Callback when voice command is parsed */
  onVoiceCommand?: (command: VoiceCommand) => void;
  /** Enable/disable wake word detection */
  enabled?: boolean;
};

type JamieWakeWordState = {
  /** Whether wake word system is active */
  isActive: boolean;
  /** Whether microphone is accessible */
  micAccessible: boolean;
  /** Whether VAD is detecting speech */
  vadActive: boolean;
  /** Last wake word detection timestamp */
  lastDetection: number | null;
  /** Error message if any */
  error: string | null;
  /** Whether system is initializing */
  initializing: boolean;
  /** Last parsed voice command */
  lastCommand: VoiceCommand | null;
};

export function useJamieWakeWord({
  onWakeWordDetected,
  onVoiceCommand,
  enabled = false,
}: UseJamieWakeWordOptions = {}): JamieWakeWordState & {
  /** Function to enable wake word detection (requires user gesture) */
  enable: () => Promise<void>;
  /** Function to disable wake word detection */
  disable: () => void;
} {
  const [lastCommand] = useState<VoiceCommand | null>(null);
  const lastDetectionTimeRef = useRef<number>(0);
  const debounceTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const wakeWordStateRef = useRef<{ rawConfidence: number | null; smoothedConfidence: number | null }>({
    rawConfidence: null,
    smoothedConfidence: null,
  });

  // Handle wake word detection with debouncing
  const handleWakeWord = useCallback(() => {
    const now = Date.now();
    const timeSinceLastDetection = now - lastDetectionTimeRef.current;

    // Clear any pending debounce timeout
    if (debounceTimeoutRef.current) {
      clearTimeout(debounceTimeoutRef.current);
      debounceTimeoutRef.current = null;
    }

    // Debounce: only trigger if enough time has passed (2 seconds default)
    if (timeSinceLastDetection >= 2000) {
      lastDetectionTimeRef.current = now;
      
      // Get current confidence values from ref
      const rawConf = wakeWordStateRef.current.rawConfidence ?? 0;
      const smoothedConf = wakeWordStateRef.current.smoothedConfidence ?? 0;
      const timestamp = new Date(now).toISOString();

      // Console indicators
      console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
      console.log('🔊 WAKE WORD DETECTED');
      console.log(`   Timestamp: ${timestamp}`);
      console.log(`   Raw Confidence: ${(rawConf * 100).toFixed(1)}%`);
      console.log(`   Smoothed Confidence: ${(smoothedConf * 100).toFixed(1)}%`);
      console.log(`   Detection Time: ${now}`);
      console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

      // Trigger callback
      onWakeWordDetected?.();
      
      // TODO: Start voice command recognition here
      if (import.meta.env.DEV) {
        console.log('[useJamieWakeWord] Ready for voice command');
      }
    } else {
      // Still within debounce window - schedule callback
      const remainingTime = 2000 - timeSinceLastDetection;
      debounceTimeoutRef.current = setTimeout(() => {
        handleWakeWord();
      }, remainingTime);
      
      if (import.meta.env.DEV) {
        console.log(`[useJamieWakeWord] Detection debounced (${remainingTime}ms remaining)`);
      }
    }
  }, [onWakeWordDetected]);

  // Use the base wake word hook
  const wakeWord = useWakeWord({
    onWakeWordDetected: handleWakeWord,
    debounceMs: 2000,
  });

  // Update ref with current confidence values
  useEffect(() => {
    wakeWordStateRef.current = {
      rawConfidence: wakeWord.rawConfidence,
      smoothedConfidence: wakeWord.smoothedConfidence,
    };
  }, [wakeWord.rawConfidence, wakeWord.smoothedConfidence]);

  // Log confidence updates in dev mode
  useEffect(() => {
    if (import.meta.env.DEV && wakeWord.isActive) {
      if (wakeWord.rawConfidence !== null || wakeWord.smoothedConfidence !== null) {
        // Only log occasionally to avoid spam (every 10th update)
        if (Math.random() < 0.1) {
          console.log(
            `[useJamieWakeWord] Confidence: raw=${(wakeWord.rawConfidence ?? 0).toFixed(3)}, ` +
            `smoothed=${(wakeWord.smoothedConfidence ?? 0).toFixed(3)}`
          );
        }
      }
    }
  }, [wakeWord.rawConfidence, wakeWord.smoothedConfidence, wakeWord.isActive]);

  // Cleanup debounce timeout on unmount
  useEffect(() => {
    return () => {
      if (debounceTimeoutRef.current) {
        clearTimeout(debounceTimeoutRef.current);
      }
    };
  }, []);

  // iOS AudioContext resume handler
  const handleUserInteraction = useCallback(() => {
    if (wakeWord.initializing || !wakeWord.isActive) {
      return;
    }

    // Resume AudioContext if suspended (iOS requirement)
    const audioContext = (window as any).audioContext;
    if (audioContext && audioContext.state === 'suspended') {
      audioContext.resume().catch((error: Error) => {
        console.warn('[useJamieWakeWord] Failed to resume AudioContext:', error);
      });
    }
  }, [wakeWord.initializing, wakeWord.isActive]);

  // Set up user interaction listeners for iOS
  useEffect(() => {
    if (!enabled) {
      return;
    }

    const events = ['click', 'touchstart', 'keydown'];
    const handlers = events.map((event) => {
      const handler = () => handleUserInteraction();
      document.addEventListener(event, handler, { once: true, passive: true });
      return { event, handler };
    });

    return () => {
      handlers.forEach(({ event, handler }) => {
        document.removeEventListener(event, handler);
      });
    };
  }, [enabled, handleUserInteraction]);

  // Update lastCommand when onVoiceCommand is called (for future integration)
  useEffect(() => {
    if (onVoiceCommand) {
      // This will be connected when voice command parsing is implemented
      // For now, lastCommand remains null
    }
  }, [onVoiceCommand]);

  return {
    ...wakeWord,
    lastCommand,
    enable: wakeWord.enable,
    disable: wakeWord.disable,
  };
}

/**
 * Example usage:
 * 
 * const { enable, disable, isActive, lastCommand } = useJamieWakeWord({
 *   onWakeWordDetected: () => {
 *     console.log('Jamie detected!');
 *   },
 *   onVoiceCommand: (command) => {
 *     if (command.intent === 'play' && command.station) {
 *       playStation(command.station);
 *     } else if (command.intent === 'volume') {
 *       adjustVolume(command.volumeLevel);
 *     }
 *   },
 *   enabled: true,
 * });
 * 
 * // Enable on user click
 * <button onClick={enable}>Start Listening</button>
 */

