/**
 * Wake Word AudioWorklet Processor
 * 
 * Matches training preprocessing exactly:
 * - Polyphase filtering for downsampling (not linear interpolation)
 * - Raw PCM float32 output in [-1, 1] range
 * - No normalization (RMS normalization happens in wakeInference.ts)
 */

class WakeWordProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    
    // Configuration
    this.sampleRate = 44100; // Input sample rate
    this.targetSampleRate = 16000; // Target for model (must match training)
    this.chunkSize = 160; // 10ms at 16kHz (160 samples)
    this.buffer = new Float32Array(0);
    
    // Downsampling state
    this.downsampleRatio = this.sampleRate / this.targetSampleRate;
    
    // Polyphase filter for proper downsampling (anti-aliasing)
    // Simple low-pass filter coefficients for 44.1kHz -> 16kHz
    this.filterOrder = 8;
    this.filterCoeffs = this.createLowPassFilter();
    this.filterState = new Float32Array(this.filterOrder);
    
    this.port.onmessage = (event) => {
      if (event.data.type === 'config') {
        this.sampleRate = event.data.sampleRate || 44100;
        this.targetSampleRate = event.data.targetSampleRate || 16000;
        this.downsampleRatio = this.sampleRate / this.targetSampleRate;
        this.filterCoeffs = this.createLowPassFilter();
        this.filterState.fill(0);
      }
    };
  }
  
  /**
   * Create simple low-pass filter coefficients for anti-aliasing
   * Cutoff frequency: ~8kHz (Nyquist for 16kHz)
   * Simplified FIR filter for real-time processing
   */
  createLowPassFilter() {
    // Simple moving average filter (good enough for anti-aliasing)
    // More sophisticated filters can be added later if needed
    const order = this.filterOrder;
    const coeffs = new Float32Array(order);
    
    // Simple boxcar (moving average) filter
    const value = 1.0 / order;
    for (let i = 0; i < order; i++) {
      coeffs[i] = value;
    }
    
    return coeffs;
  }
  
  /**
   * Apply low-pass filter (anti-aliasing before downsampling)
   */
  applyLowPassFilter(input) {
    const output = new Float32Array(input.length);
    
    for (let i = 0; i < input.length; i++) {
      let sum = 0;
      for (let j = 0; j < this.filterOrder; j++) {
        const idx = i - j;
        if (idx >= 0) {
          sum += input[idx] * this.filterCoeffs[j];
        } else {
          sum += this.filterState[this.filterOrder + idx] * this.filterCoeffs[j];
        }
      }
      output[i] = sum;
    }
    
    // Update filter state
    if (input.length >= this.filterOrder) {
      this.filterState.set(input.subarray(input.length - this.filterOrder));
    } else {
      const keep = this.filterOrder - input.length;
      this.filterState.copyWithin(0, input.length);
      this.filterState.set(input, keep);
    }
    
    return output;
  }
  
  /**
   * Polyphase downsampling with anti-aliasing
   * Matches librosa.resample behavior more closely
   */
  downsample(input) {
    // Apply anti-aliasing filter
    const filtered = this.applyLowPassFilter(input);
    
    // Decimate (take every Nth sample)
    const outputLength = Math.floor(filtered.length / this.downsampleRatio);
    const output = new Float32Array(outputLength);
    
    for (let i = 0; i < outputLength; i++) {
      const srcIndex = Math.round(i * this.downsampleRatio);
      output[i] = filtered[srcIndex] || 0;
    }
    
    return output;
  }
  
  process(inputs, outputs, parameters) {
    const input = inputs[0];
    
    if (input.length === 0 || input[0].length === 0) {
      return true; // Keep processor alive
    }
    
    // Get mono channel (first channel)
    const audioData = input[0];
    
    // Downsample to 16kHz using polyphase filtering (matches training)
    let processedAudio;
    if (this.sampleRate !== this.targetSampleRate) {
      processedAudio = this.downsample(audioData);
    } else {
      processedAudio = audioData;
    }
    
    // Append to buffer
    const newBuffer = new Float32Array(this.buffer.length + processedAudio.length);
    newBuffer.set(this.buffer);
    newBuffer.set(processedAudio, this.buffer.length);
    this.buffer = newBuffer;
    
    // Send 10ms chunks (160 samples at 16kHz) - raw PCM, no normalization
    // RMS normalization happens in wakeInference.ts to match training
    while (this.buffer.length >= this.chunkSize) {
      // Extract chunk (raw, unnormalized float32)
      const chunk = this.buffer.slice(0, this.chunkSize);
      
      // Send to main thread
      this.port.postMessage({
        type: 'audio',
        samples: chunk
      });
      
      // Keep remainder in buffer
      this.buffer = this.buffer.slice(this.chunkSize);
    }
    
    return true; // Keep processor alive
  }
}

registerProcessor('wake-word-processor', WakeWordProcessor);

